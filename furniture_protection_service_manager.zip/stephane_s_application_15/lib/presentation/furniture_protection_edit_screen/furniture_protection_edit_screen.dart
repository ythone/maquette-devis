import 'package:flutter/material.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_image_view.dart';
import '../../widgets/custom_number_input.dart';
import './controller/furniture_protection_edit_controller.dart';

class FurnitureProtectionEditScreen
    extends GetWidget<FurnitureProtectionEditController> {
  FurnitureProtectionEditScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.blackCustom,
      body: SafeArea(
        child: Container(
          height: 667.h,
          width: 375.h,
          child: Column(
            children: [
              SizedBox(height: 16.h),
              Expanded(
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 16.h),
                  decoration: BoxDecoration(
                    color: appTheme.whiteCustom,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(16.h),
                      topRight: Radius.circular(16.h),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: appTheme.blackCustom,
                        blurRadius: 25.h,
                        spreadRadius: 0,
                        offset: Offset(0, 20.h),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Expanded(
                        child: Padding(
                          padding: EdgeInsets.all(16.h),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildHeader(),
                              SizedBox(height: 24.h),
                              Expanded(
                                child: SingleChildScrollView(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      _buildSurfaceAreaSection(),
                                      SizedBox(height: 24.h),
                                      _buildWorkersSection(),
                                      SizedBox(height: 24.h),
                                      _buildLaborSection(),
                                      SizedBox(height: 24.h),
                                      _buildLinkedProductsSection(),
                                      SizedBox(height: 24.h),
                                      _buildSummarySection(),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      _buildActionButtons(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Éditer: Protéger les Meubles et les',
                style: TextStyleHelper.instance.title18SemiBold
                    .copyWith(height: 1.22),
              ),
              SizedBox(height: 4.h),
              Text(
                'Appareillages',
                style: TextStyleHelper.instance.title18SemiBold
                    .copyWith(height: 1.22),
              ),
            ],
          ),
        ),
        GestureDetector(
          onTap: () => Get.back(),
          child: Padding(
            padding: EdgeInsets.only(top: 8.h),
            child: CustomImageView(
              imagePath: ImageConstant.imgSvg,
              height: 16.h,
              width: 12.h,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSurfaceAreaSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Superficie (m2)',
          style: TextStyleHelper.instance.body14Medium,
        ),
        SizedBox(height: 8.h),
        Obx(() => CustomNumberInput(
              controller: controller.surfaceAreaController,
              initialValue: controller
                      .furnitureProtectionEditModel.value?.surfaceArea?.value ??
                  '50',
              hintText: 'Enter surface area',
              labelText: null,
              onChanged: (value) => controller.updateSurfaceArea(value),
            )),
      ],
    );
  }

  Widget _buildWorkersSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Nombre de tâcherons',
          style: TextStyleHelper.instance.body14Medium,
        ),
        SizedBox(height: 8.h),
        Obx(() => CustomNumberInput(
              controller: controller.workersController,
              initialValue: controller.furnitureProtectionEditModel.value
                      ?.numberOfWorkers?.value ??
                  '1',
              hintText: 'Enter number of workers',
              labelText: null,
              onChanged: (value) => controller.updateNumberOfWorkers(value),
            )),
      ],
    );
  }

  Widget _buildLaborSection() {
    return Container(
      padding: EdgeInsets.all(16.h),
      decoration: BoxDecoration(
        color: appTheme.colorFFEFF6,
        borderRadius: BorderRadius.circular(8.h),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Main d\'Œuvre',
            style: TextStyleHelper.instance.title16Medium,
          ),
          SizedBox(height: 16.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Prix plancher',
                    style: TextStyleHelper.instance.body12,
                  ),
                  Obx(() => Text(
                        '${controller.furnitureProtectionEditModel.value?.laborFloorPrice?.value ?? '400'} FCFA',
                        style: TextStyleHelper.instance.body14,
                      )),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    'Prix plafond',
                    style: TextStyleHelper.instance.body12,
                  ),
                  Obx(() => Text(
                        '${controller.furnitureProtectionEditModel.value?.laborCeilingPrice?.value ?? '450'} FCFA',
                        style: TextStyleHelper.instance.body14,
                      )),
                ],
              ),
            ],
          ),
          SizedBox(height: 16.h),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Prix appliqué',
                style: TextStyleHelper.instance.body14Medium,
              ),
              SizedBox(height: 8.h),
              Container(
                height: 42.h,
                padding: EdgeInsets.symmetric(horizontal: 12.h, vertical: 8.h),
                decoration: BoxDecoration(
                  color: appTheme.whiteCustom,
                  border: Border.all(color: appTheme.colorFFD1D5),
                  borderRadius: BorderRadius.circular(6.h),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Obx(() => Text(
                            controller.furnitureProtectionEditModel.value
                                    ?.laborAppliedPrice?.value ??
                                '450',
                            style: TextStyleHelper.instance.title16,
                          )),
                    ),
                    CustomImageView(
                      imagePath: ImageConstant.imgVector,
                      height: 14.h,
                      width: 15.h,
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 8.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Min: 400 FCFA',
                style: TextStyleHelper.instance.body12
                    .copyWith(color: appTheme.colorFF9CA3),
              ),
              Text(
                'Max: 450 FCFA',
                style: TextStyleHelper.instance.body12
                    .copyWith(color: appTheme.colorFF9CA3),
              ),
            ],
          ),
          SizedBox(height: 8.h),
          RichText(
            text: TextSpan(
              children: [
                TextSpan(
                  text: 'Total MO: ',
                  style: TextStyleHelper.instance.body14
                      .copyWith(color: appTheme.colorFF4B55),
                ),
                TextSpan(
                  text: '22 500 FCFA',
                  style: TextStyleHelper.instance.body14Medium
                      .copyWith(color: appTheme.colorFF263C),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLinkedProductsSection() {
    return Container(
      padding: EdgeInsets.all(16.h),
      decoration: BoxDecoration(
        color: appTheme.colorFFF0FD,
        borderRadius: BorderRadius.circular(8.h),
        border: Border.all(color: appTheme.colorFFE5E7),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Produits Liés',
            style: TextStyleHelper.instance.title16Medium,
          ),
          SizedBox(height: 16.h),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Protéger les Meubles et les',
                style: TextStyleHelper.instance.title16Medium,
              ),
              Text(
                'Appareillages',
                style: TextStyleHelper.instance.title16Medium,
              ),
              Text(
                '(Service par mètre carré)',
                style: TextStyleHelper.instance.body14,
              ),
            ],
          ),
          SizedBox(height: 16.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Estimée:',
                style: TextStyleHelper.instance.body12,
              ),
              Text(
                'Sécurité:',
                style: TextStyleHelper.instance.body12,
              ),
              Text(
                'Total:',
                style: TextStyleHelper.instance.body12,
              ),
            ],
          ),
          SizedBox(height: 4.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Obx(() => Text(
                    controller.furnitureProtectionEditModel.value
                            ?.estimatedQuantity?.value ??
                        '50',
                    style: TextStyleHelper.instance.body12Medium,
                  )),
              Obx(() => Text(
                    controller.furnitureProtectionEditModel.value
                            ?.securityQuantity?.value ??
                        '3',
                    style: TextStyleHelper.instance.body12Medium,
                  )),
              Obx(() => Text(
                    controller.furnitureProtectionEditModel.value?.totalQuantity
                            ?.value ??
                        '53',
                    style: TextStyleHelper.instance.body12Medium
                        .copyWith(color: appTheme.colorFF263C),
                  )),
            ],
          ),
          SizedBox(height: 16.h),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Ajustement sécurité (%)',
                style: TextStyleHelper.instance.body14Medium,
              ),
              SizedBox(height: 8.h),
              Container(
                height: 16.h,
                decoration: BoxDecoration(
                  color: appTheme.whiteCustom,
                  borderRadius: BorderRadius.circular(8.h),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: 4.h,
                      top: 0,
                      child: Obx(() => Text(
                            controller.furnitureProtectionEditModel.value
                                    ?.securityAdjustment?.value ??
                                '10',
                            style: TextStyleHelper.instance.title16
                                .copyWith(height: 1.5),
                          )),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 8.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '10%',
                    style: TextStyleHelper.instance.body12
                        .copyWith(color: appTheme.colorFF6B72),
                  ),
                  Text(
                    '5%',
                    style: TextStyleHelper.instance.body12
                        .copyWith(color: appTheme.colorFF6B72),
                  ),
                  Text(
                    '50%',
                    style: TextStyleHelper.instance.body12
                        .copyWith(color: appTheme.colorFF6B72),
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: 16.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Prix Technicien',
                style: TextStyleHelper.instance.body12,
              ),
              Text(
                'Prix Patron',
                style: TextStyleHelper.instance.body12,
              ),
            ],
          ),
          SizedBox(height: 4.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Obx(() => Text(
                    '${controller.furnitureProtectionEditModel.value?.technicianPrice?.value ?? '450'} FCFA',
                    style: TextStyleHelper.instance.body14,
                  )),
              Obx(() => Text(
                    '${controller.furnitureProtectionEditModel.value?.bossPrice?.value ?? '500'} FCFA',
                    style: TextStyleHelper.instance.body14,
                  )),
            ],
          ),
          SizedBox(height: 16.h),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Prix appliqué',
                style: TextStyleHelper.instance.body14Medium,
              ),
              SizedBox(height: 8.h),
              Container(
                height: 42.h,
                padding: EdgeInsets.symmetric(horizontal: 12.h, vertical: 8.h),
                child: Row(
                  children: [
                    Expanded(
                      child: Obx(() => Text(
                            controller.furnitureProtectionEditModel.value
                                    ?.productAppliedPrice?.value ??
                                '450',
                            style: TextStyleHelper.instance.title16
                                .copyWith(height: 1.5),
                          )),
                    ),
                    CustomImageView(
                      imagePath: ImageConstant.imgVectorBlueGray300,
                      height: 14.h,
                      width: 14.h,
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 8.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Min: 450 FCFA',
                style: TextStyleHelper.instance.body12
                    .copyWith(color: appTheme.colorFF9CA3),
              ),
              Text(
                'Max: 500 FCFA',
                style: TextStyleHelper.instance.body12
                    .copyWith(color: appTheme.colorFF9CA3),
              ),
            ],
          ),
          SizedBox(height: 8.h),
          RichText(
            text: TextSpan(
              children: [
                TextSpan(
                  text: 'Total: ',
                  style: TextStyleHelper.instance.body14
                      .copyWith(color: appTheme.colorFF4B55),
                ),
                TextSpan(
                  text: '23 850 FCFA',
                  style: TextStyleHelper.instance.body14Medium
                      .copyWith(color: appTheme.colorFF263C),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummarySection() {
    return Container(
      padding: EdgeInsets.all(16.h),
      decoration: BoxDecoration(
        color: appTheme.colorFFF9FA,
        borderRadius: BorderRadius.circular(8.h),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Récapitulatif',
            style: TextStyleHelper.instance.title16Medium,
          ),
          SizedBox(height: 16.h),
          Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Total Main d\'Œuvre:',
                    style: TextStyleHelper.instance.body14
                        .copyWith(color: appTheme.blackCustom),
                  ),
                  Obx(() => Text(
                        '${controller.furnitureProtectionEditModel.value?.totalLabor?.value ?? '22 500'} FCFA',
                        style: TextStyleHelper.instance.body14Medium
                            .copyWith(color: appTheme.blackCustom),
                      )),
                ],
              ),
              SizedBox(height: 8.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Total Produits:',
                    style: TextStyleHelper.instance.body14
                        .copyWith(color: appTheme.blackCustom),
                  ),
                  Obx(() => Text(
                        '${controller.furnitureProtectionEditModel.value?.totalProducts?.value ?? '23 850'} FCFA',
                        style: TextStyleHelper.instance.body14Medium
                            .copyWith(color: appTheme.blackCustom),
                      )),
                ],
              ),
              SizedBox(height: 8.h),
              Container(
                padding: EdgeInsets.only(top: 8.h),
                decoration: BoxDecoration(
                  border: Border(
                    top: BorderSide(color: appTheme.colorFFE5E7),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Total Tâche:',
                      style: TextStyleHelper.instance.body14Bold,
                    ),
                    Obx(() => Text(
                          '${controller.furnitureProtectionEditModel.value?.totalTask?.value ?? '46 350'} FCFA',
                          style: TextStyleHelper.instance.body14Bold
                              .copyWith(color: appTheme.colorFF263C),
                        )),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 16.h),
          CustomButton(
            text: 'Vérifier tous les prix',
            onPressed: () => controller.verifyAllPrices(),
            height: 36.h,
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Container(
      padding: EdgeInsets.all(16.h),
      decoration: BoxDecoration(
        color: appTheme.colorFFF9FA,
      ),
      child: Column(
        children: [
          CustomButton(
            text: 'Sauvegarder',
            onPressed: () => controller.saveChanges(),
            backgroundColor: appTheme.colorFF263C,
            height: 42.h,
          ),
          SizedBox(height: 12.h),
          CustomButton(
            text: 'Annuler',
            onPressed: () => controller.cancelChanges(),
            backgroundColor: appTheme.whiteCustom,
            textColor: appTheme.colorFF3741,
            height: 42.h,
          ),
        ],
      ),
    );
  }
}
