import 'package:get/get.dart';
import '../controller/furniture_protection_edit_controller.dart';
import '../../../core/app_export.dart';

class FurnitureProtectionEditBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => FurnitureProtectionEditController());
  }
}
