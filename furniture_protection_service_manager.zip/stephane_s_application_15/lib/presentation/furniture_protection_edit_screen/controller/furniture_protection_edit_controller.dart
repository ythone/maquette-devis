import 'package:flutter/material.dart';
import '../models/furniture_protection_edit_model.dart';
import '../../../core/app_export.dart';

class FurnitureProtectionEditController extends GetxController {
  late TextEditingController surfaceAreaController;
  late TextEditingController workersController;

  Rx<FurnitureProtectionEditModel?> furnitureProtectionEditModel =
      Rx<FurnitureProtectionEditModel?>(null);

  @override
  void onInit() {
    super.onInit();
    surfaceAreaController = TextEditingController();
    workersController = TextEditingController();

    furnitureProtectionEditModel.value = FurnitureProtectionEditModel();

    surfaceAreaController.text =
        furnitureProtectionEditModel.value?.surfaceArea?.value ?? '50';
    workersController.text =
        furnitureProtectionEditModel.value?.numberOfWorkers?.value ?? '1';
  }

  @override
  void onClose() {
    surfaceAreaController.dispose();
    workersController.dispose();
    super.onClose();
  }

  void updateSurfaceArea(String value) {
    if (furnitureProtectionEditModel.value != null) {
      furnitureProtectionEditModel.value!.surfaceArea?.value = value;
      surfaceAreaController.text = value;
    }
  }

  void updateNumberOfWorkers(String value) {
    if (furnitureProtectionEditModel.value != null) {
      furnitureProtectionEditModel.value!.numberOfWorkers?.value = value;
      workersController.text = value;
    }
  }

  void verifyAllPrices() {
    Get.snackbar(
      'Vérification',
      'Vérification des prix en cours...',
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: appTheme.blueCustom,
      colorText: appTheme.whiteCustom,
    );
  }

  void saveChanges() {
    Get.snackbar(
      'Sauvegarde',
      'Modifications sauvegardées avec succès!',
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: appTheme.greenCustom,
      colorText: appTheme.whiteCustom,
    );
  }

  void cancelChanges() {
    Get.dialog(
      AlertDialog(
        title: Text('Confirmation'),
        content: Text('Êtes-vous sûr de vouloir annuler les modifications?'),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: Text('Non'),
          ),
          TextButton(
            onPressed: () {
              Get.back();
              Get.back();
            },
            child: Text('Oui'),
          ),
        ],
      ),
    );
  }
}
