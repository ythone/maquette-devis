import 'package:get/get.dart';
import '../../../core/app_export.dart';

class FurnitureProtectionEditModel {
  Rx<String>? surfaceArea;
  Rx<String>? numberOfWorkers;
  Rx<String>? laborFloorPrice;
  Rx<String>? laborCeilingPrice;
  Rx<String>? laborAppliedPrice;
  Rx<String>? totalLabor;
  Rx<String>? estimatedQuantity;
  Rx<String>? securityQuantity;
  Rx<String>? totalQuantity;
  Rx<String>? securityAdjustment;
  Rx<String>? technicianPrice;
  Rx<String>? bossPrice;
  Rx<String>? productAppliedPrice;
  Rx<String>? totalProducts;
  Rx<String>? totalTask;

  FurnitureProtectionEditModel({
    this.surfaceArea,
    this.numberOfWorkers,
    this.laborFloorPrice,
    this.laborCeilingPrice,
    this.laborAppliedPrice,
    this.totalLabor,
    this.estimatedQuantity,
    this.securityQuantity,
    this.totalQuantity,
    this.securityAdjustment,
    this.technicianPrice,
    this.bossPrice,
    this.productAppliedPrice,
    this.totalProducts,
    this.totalTask,
  }) {
    surfaceArea = surfaceArea ?? '50'.obs;
    numberOfWorkers = numberOfWorkers ?? '1'.obs;
    laborFloorPrice = laborFloorPrice ?? '400'.obs;
    laborCeilingPrice = laborCeilingPrice ?? '450'.obs;
    laborAppliedPrice = laborAppliedPrice ?? '450'.obs;
    totalLabor = totalLabor ?? '22 500'.obs;
    estimatedQuantity = estimatedQuantity ?? '50'.obs;
    securityQuantity = securityQuantity ?? '3'.obs;
    totalQuantity = totalQuantity ?? '53'.obs;
    securityAdjustment = securityAdjustment ?? '10'.obs;
    technicianPrice = technicianPrice ?? '450'.obs;
    bossPrice = bossPrice ?? '500'.obs;
    productAppliedPrice = productAppliedPrice ?? '450'.obs;
    totalProducts = totalProducts ?? '23 850'.obs;
    totalTask = totalTask ?? '46 350'.obs;
  }
}
