import 'package:flutter/material.dart';

import '../core/app_export.dart';

/**
 * CustomButton - A reusable button component with customizable appearance and behavior
 * 
 * Features:
 * - Configurable text, colors, and dimensions
 * - Full width by default with optional width override
 * - Loading state support
 * - Responsive sizing using SizeUtils
 * - Material design elevation and styling
 * 
 * @param text - The text to display on the button
 * @param onPressed - Callback function when button is tapped
 * @param backgroundColor - Background color of the button
 * @param textColor - Color of the button text
 * @param height - Height of the button
 * @param width - Width of the button (defaults to full width)
 * @param borderRadius - Corner radius of the button
 * @param isEnabled - Whether the button is enabled
 * @param isLoading - Whether to show loading spinner
 * @param fontSize - Font size of the button text
 * @param fontWeight - Font weight of the button text
 */
class CustomButton extends StatelessWidget {
  const CustomButton({
    Key? key,
    required this.text,
    this.onPressed,
    this.backgroundColor,
    this.textColor,
    this.height,
    this.width,
    this.borderRadius,
    this.isEnabled,
    this.isLoading,
    this.fontSize,
    this.fontWeight,
  }) : super(key: key);

  /// The text to display on the button
  final String text;

  /// Callback function when button is tapped
  final VoidCallback? onPressed;

  /// Background color of the button
  final Color? backgroundColor;

  /// Color of the button text
  final Color? textColor;

  /// Height of the button
  final double? height;

  /// Width of the button (null for full width)
  final double? width;

  /// Corner radius of the button
  final double? borderRadius;

  /// Whether the button is enabled
  final bool? isEnabled;

  /// Whether to show loading spinner
  final bool? isLoading;

  /// Font size of the button text
  final double? fontSize;

  /// Font weight of the button text
  final FontWeight? fontWeight;

  @override
  Widget build(BuildContext context) {
    final bool enabled = isEnabled ?? true;
    final bool loading = isLoading ?? false;
    final Color bgColor = backgroundColor ?? appTheme.colorFF2563;
    final Color txtColor = textColor ?? appTheme.whiteCustom;
    final double btnHeight = height ?? 36.h;
    final double btnBorderRadius = borderRadius ?? 6.h;
    final double txtFontSize = fontSize ?? 14.fSize;
    final FontWeight txtFontWeight = fontWeight ?? FontWeight.w400;

    return SizedBox(
      width: width ?? double.infinity,
      height: btnHeight,
      child: ElevatedButton(
        onPressed: enabled && !loading ? onPressed : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: bgColor,
          foregroundColor: txtColor,
          disabledBackgroundColor: bgColor.withAlpha(153),
          disabledForegroundColor: txtColor.withAlpha(153),
          elevation: 2,
          shadowColor: Colors.black26,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(btnBorderRadius),
          ),
          padding: EdgeInsets.symmetric(horizontal: 16.h),
        ),
        child: loading
            ? SizedBox(
                width: 20.h,
                height: 20.h,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation<Color>(txtColor),
                ),
              )
            : Text(
                text,
                style: TextStyleHelper.instance.bodyTextRoboto,
              ),
      ),
    );
  }
}
