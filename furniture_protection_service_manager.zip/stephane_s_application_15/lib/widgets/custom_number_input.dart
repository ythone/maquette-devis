import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/app_export.dart';

/**
 * CustomNumberInput - A reusable number input field component
 * 
 * This component provides a styled number input field with customizable
 * properties including initial value, placeholder text, label, and validation.
 * 
 * @param controller - TextEditingController for managing input value
 * @param initialValue - Initial numeric value to display
 * @param hintText - Placeholder text shown when field is empty
 * @param labelText - Label text for accessibility and form description
 * @param onChanged - Callback function triggered when input value changes
 * @param validator - Function to validate input value
 * @param isEnabled - Whether the input field is enabled or disabled
 * @param maxValue - Maximum allowed numeric value
 * @param minValue - Minimum allowed numeric value
 */
class CustomNumberInput extends StatelessWidget {
  const CustomNumberInput({
    super.key,
    this.controller,
    this.initialValue,
    this.hintText,
    this.labelText,
    this.onChanged,
    this.validator,
    this.isEnabled,
    this.maxValue,
    this.minValue,
  });

  /// Controller for managing the input field's text
  final TextEditingController? controller;

  /// Initial value to display in the input field
  final String? initialValue;

  /// Placeholder text shown when the field is empty
  final String? hintText;

  /// Label text for accessibility and form description
  final String? labelText;

  /// Callback function triggered when the input value changes
  final Function(String)? onChanged;

  /// Function to validate the input value
  final String? Function(String?)? validator;

  /// Whether the input field is enabled or disabled
  final bool? isEnabled;

  /// Maximum allowed numeric value
  final double? maxValue;

  /// Minimum allowed numeric value
  final double? minValue;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      initialValue: controller == null ? (initialValue ?? "50") : null,
      keyboardType: TextInputType.number,
      enabled: isEnabled ?? true,
      style: TextStyleHelper.instance.title16Roboto,
      inputFormatters: [
        FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
        if (maxValue != null || minValue != null)
          _NumberRangeFormatter(minValue: minValue, maxValue: maxValue),
      ],
      decoration: InputDecoration(
        hintText: hintText ?? "Enter number",
        labelText: labelText,
        contentPadding: EdgeInsets.symmetric(
          horizontal: 12.h,
          vertical: 8.h,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(6.h),
          borderSide: BorderSide(
            color: appTheme.colorFFD1D5,
            width: 1.h,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(6.h),
          borderSide: BorderSide(
            color: appTheme.colorFFD1D5,
            width: 1.h,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(6.h),
          borderSide: BorderSide(
            color: appTheme.colorFF3B82,
            width: 2.h,
          ),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(6.h),
          borderSide: BorderSide(
            color: appTheme.redCustom,
            width: 1.h,
          ),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(6.h),
          borderSide: BorderSide(
            color: appTheme.redCustom,
            width: 2.h,
          ),
        ),
        filled: true,
        fillColor: appTheme.whiteCustom,
        hintStyle: TextStyleHelper.instance.title16Roboto
            .copyWith(color: appTheme.colorFF9CA3),
        labelStyle: TextStyleHelper.instance.title16Roboto
            .copyWith(color: appTheme.colorFF3741),
      ),
      onChanged: onChanged,
      validator: validator,
    );
  }
}

class _NumberRangeFormatter extends TextInputFormatter {
  final double? minValue;
  final double? maxValue;

  _NumberRangeFormatter({this.minValue, this.maxValue});

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    if (newValue.text.isEmpty) {
      return newValue;
    }

    final double? value = double.tryParse(newValue.text);
    if (value == null) {
      return oldValue;
    }

    if (minValue != null && value < minValue!) {
      return oldValue;
    }

    if (maxValue != null && value > maxValue!) {
      return oldValue;
    }

    return newValue;
  }
}
